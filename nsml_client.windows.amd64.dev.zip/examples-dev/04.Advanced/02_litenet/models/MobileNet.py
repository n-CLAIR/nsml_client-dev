import torch
import torch.nn as nn
import torchvision.models as models
import torch.utils.model_zoo as model_zoo
import torch.nn.functional as F
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True

def conv_bn(inp, oup, stride):
  return nn.Sequential(
    nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
    nn.BatchNorm2d(oup),
    nn.ReLU(inplace=True)
  )

def conv_sc(inp, oup, stride):
  return nn.Sequential(
    nn.Conv2d(inp, inp, 3, stride, 1, groups=inp, bias=False),
    nn.BatchNorm2d(inp),
    nn.ReLU(inplace=True),

    nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
    nn.BatchNorm2d(oup),
    nn.ReLU(inplace=True),
  )

class Net(nn.Module):
  def __init__(self, in_c=3, image_size=224, base=32, num_classes=1000, ngpu=1):
    super(Net, self).__init__()
    self.ngpu = ngpu
    self.base = base

    if image_size == 224:
      self.model = nn.Sequential(
        #224 256 32 32
        conv_bn(3,base, 2), 
        #112 128 16 32
        conv_sc(base, base*2, 1),
        conv_sc(base*2, base*4, 2),
        #56 64 8 32
        conv_sc(base*4, base*4, 1),
        conv_sc(base*4, base*8, 2),
        #28 32 4 16
        conv_sc(base*8, base*8, 1),
        conv_sc(base*8, base*16, 2),
        #14 16 2 8
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*32, 2),
        #7 8 1 4 
        conv_sc(base*32, base*32, 1),
        #nn.AvgPool2d(7),
      )
    elif image_size == 32:
      self.model = nn.Sequential(
        conv_bn(3,base, 1), 
        conv_sc(base, base*2, 1),
        conv_sc(base*2, base*4, 2),
        conv_sc(base*4, base*4, 1),
        conv_sc(base*4, base*8, 1),
        conv_sc(base*8, base*8, 1),
        conv_sc(base*8, base*16, 2),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*16, 1),
        conv_sc(base*16, base*32, 1),
        conv_sc(base*32, base*32, 1),
        #nn.AvgPool2d(7),
      )
    self.fc = nn.Linear(base*32, num_classes)

  def forward(self, x):
    if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
      x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
    else: 
      x = self.model(x)
    x = F.avg_pool2d(x, kernel_size=x.size()[2:])
    #x = F.avg_pool2d(x, kernel_size=8)
    x = x.view(-1, self.base*32)
    x = self.fc(x)
    return x
