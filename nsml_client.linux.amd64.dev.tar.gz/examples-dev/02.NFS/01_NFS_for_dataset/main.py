import argparse
import os

import nsml
from nsml import DATASET_PATH
from nsml import SESSION_NAME


# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--mode', type=str, default='train')
parser.add_argument('--iteration', type=str, default='0')
parser.add_argument('--pause', type=int, default=0)
args = parser.parse_args()

binded_args = 10
nsml.bind(binded_args=binded_args)

if args.pause:
    nsml.paused(scope=locals())

# NOTE: DATASET_PATH is for read-only
# write result in "NSML_NFS_OUTPUT" directory
with open(os.path.join(DATASET_PATH, 'result.txt'), 'w') as fp:
    fp.write('{} nfs write!!\n'.format(SESSION_NAME))

# read written result from "DATASET_PATH"
with open(os.path.join(DATASET_PATH, 'result.txt'), 'r') as fp:
    print(fp.read())

# save for testing fork, resume and infer
nsml.save(0)
