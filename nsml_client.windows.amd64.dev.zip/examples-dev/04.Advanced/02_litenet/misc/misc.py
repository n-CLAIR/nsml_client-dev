import torch
import os
import sys


def check_model_complexity(m):
    num_params = get_num_params(m)
    size_params = get_size_params_in_MB(num_params)
    return num_params, size_params


def get_num_params(model):
    import numpy as np
    num_params = 0
    for p in model.parameters():
        num_params += np.prod(p.size())
    return num_params


def get_size_params_in_MB(num_params):
    size_bytes = num_params * 4
    return size_bytes / 1024. / 1024.


def get_approx_flops(_):
    # NOTE hard-wired computation referring to Deep Residual Learning for Image Recognition, 2015
    resnet101_full_paper = 10 ** 9 * 7.6
    dense = 2048 * 1000
    conv5x = 7 * 7 * (1 * 1 * 1024 * 512 + 3 * 3 * 512 * 512 + 1 * 1 * 521 * 2048) * 3
    conv4x = 14 * 14 * (1 * 1 * 512 * 256 + 3 * 3 * 256 * 256 + 1 * 1 * 256 * 1024) * 23
    conv3x = 28 * 28 * (1 * 1 * 256 * 128 + 3 * 3 * 128 * 128 + 1 * 1 * 128 * 512) * 4
    conv2x = 56 * 56 * (1 * 1 * 64 * 64 + 3 * 3 * 64 * 64 + 1 * 1 * 64 * 256) * 3
    conv1 = 224 * 224 * (7 * 7 * 3 * 64) / 2
    approx_resnet101_full = dense + conv5x + conv4x + conv3x + conv2x + conv1
    resnet101FE1 = resnet101_full_paper - dense
    resnet101FE32 = resnet101FE1 - conv5x - conv4x
    return resnet101_full_paper, resnet101FE1, resnet101FE32


def create_exp_dir(exp):
    try:
        os.makedirs(exp)
        print('Creating exp dir: %s' % exp)
    except OSError:
        pass
    return True


def get_svhn_loader(dataroot, split='train', batch_size=64, workers=4, use_dtcwt=False, num_passes=0):
    import datasets as dset
    import torchvision.transforms as transforms
    import models.DTCWT as net

    if use_dtcwt and split == 'train':
        transform = transforms.Compose([transforms.ToTensor(),
                                        net.ComplexWavelet(num_passes=num_passes)])
    elif use_dtcwt and split != 'train':
        transform = transforms.Compose([transforms.ToTensor(),
                                        net.ComplexWavelet(num_passes=num_passes)])
    elif not use_dtcwt and split == 'train':
        transform = transforms.Compose([transforms.ToTensor()])
    elif not use_dtcwt and split != 'train':
        transform = transforms.Compose([transforms.ToTensor()])

    shuffle_flag = True if split == 'train' else False
    dataset = dset.SVHN(dataroot, split=split, transform=transform, target_transform=None, download=True)
    assert dataset
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=shuffle_flag, num_workers=workers)
    return dataloader


def get_cifar_loader(dataroot, split='train', batch_size=64, workers=4, use_dtcwt=False, num_passes=0, no_aug=False):
    import torchvision.datasets as dset
    import torchvision.transforms as transforms
    import models.DTCWT as net

    mean, std = (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)

    if use_dtcwt and split == 'train':
        if not no_aug:
            transform = transforms.Compose([transforms.RandomCrop(32, padding=4),
                                            transforms.RandomHorizontalFlip(),
                                            transforms.ToTensor(),
                                            net.ComplexWavelet(num_passes=num_passes)])
        else:
            transform = transforms.Compose([transforms.ToTensor(),
                                            net.ComplexWavelet(num_passes=num_passes)])
    elif use_dtcwt and split != 'train':
        transform = transforms.Compose([transforms.ToTensor(),
                                        net.ComplexWavelet(num_passes=num_passes)])
    elif not use_dtcwt and split == 'train':
        if not no_aug:
            transform = transforms.Compose([transforms.RandomCrop(32, padding=4),
                                            transforms.RandomHorizontalFlip(),
                                            transforms.ToTensor(),
                                            transforms.Normalize(mean, std)])
        else:
            transform = transforms.Compose([transforms.ToTensor(),
                                            transforms.Normalize(mean, std)])
    elif not use_dtcwt and split != 'train':
        transform = transforms.Compose([transforms.ToTensor(),
                                        transforms.Normalize(mean, std)])

    set_flag = True if split == 'train' else False
    shuffle_flag = True if split == 'train' else False
    dataset = dset.CIFAR10(dataroot, train=set_flag, transform=transform, target_transform=None, download=True)
    assert dataset
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=shuffle_flag, num_workers=workers)
    return dataloader


def get_imagenet_loader(dataroot, original_size=256, image_size=224, batch_size=64, workers=4, split='train',
                        use_dtcwt=False, num_passes=0):
    from torchvision.datasets.folder import ImageFolder as commonDataset
    import torchvision.transforms as transforms
    import models.DTCWT as net

    if use_dtcwt and split == 'train':
        dataset = commonDataset(root=dataroot,
                                transform=transforms.Compose([
                                    transforms.RandomSizedCrop(image_size),
                                    transforms.RandomHorizontalFlip(),
                                    transforms.ToTensor(),
                                    net.ComplexWavelet(num_passes=num_passes)]))
        assert dataset
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=workers,
                                                 pin_memory=True)
    elif use_dtcwt:
        dataset = commonDataset(root=dataroot,
                                transform=transforms.Compose([
                                    transforms.Scale(original_size),
                                    transforms.CenterCrop(image_size),
                                    transforms.ToTensor(),
                                    net.ComplexWavelet(num_passes=num_passes)]))
        assert dataset
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=workers,
                                                 pin_memory=True)

    mean, std = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
    if not use_dtcwt and split == 'train':
        dataset = commonDataset(root=dataroot,
                                transform=transforms.Compose([
                                    transforms.RandomSizedCrop(image_size),
                                    transforms.RandomHorizontalFlip(),
                                    transforms.ToTensor(),
                                    transforms.Normalize(mean, std)]))
        assert dataset
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=workers)
    elif not use_dtcwt:
        dataset = commonDataset(root=dataroot,
                                transform=transforms.Compose([
                                    transforms.Scale(original_size),
                                    transforms.CenterCrop(image_size),
                                    transforms.ToTensor(),
                                    transforms.Normalize(mean, std)]))
        assert dataset
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=workers)

    return dataloader


def get_loader(dataroot, original_size=256, image_size=224,
               batch_size=64, val_batch_size=1, workers=4,
               mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225),
               k_fold=5, k=0, data_format='images',
               use_dtcwt=True, num_passes=3):
    from libs.hdf5_pytorch import HDF5Dataset as commonDataset
    import torchvision.transforms as transforms
    from torchsample.transforms import RandomAffine

    if not use_dtcwt:
        transform_trn = transforms.Compose([transforms.Scale(original_size),
                                            transforms.RandomCrop(image_size),
                                            transforms.RandomHorizontalFlip(),
                                            transforms.ToTensor(),
                                            transforms.Normalize(mean, std),
                                            RandomAffine(rotation_range=6, shear_range=6, zoom_range=(0.9, 1.1))
                                            ])
        transform_val = transforms.Compose([transforms.Scale(original_size),
                                            transforms.CenterCrop(image_size),
                                            transforms.ToTensor(),
                                            transforms.Normalize(mean, std)
                                            ])
    elif use_dtcwt:
        import models.DTCWT as net
        transform_trn = transforms.Compose([transforms.Scale(original_size),
                                            transforms.RandomCrop(image_size),
                                            transforms.RandomHorizontalFlip(),
                                            transforms.ToTensor(),
                                            RandomAffine(rotation_range=6, shear_range=6, zoom_range=(0.9, 1.1)),
                                            net.ComplexWavelet(num_passes=num_passes),
                                            ])
        transform_val = transforms.Compose([transforms.Scale(original_size),
                                            transforms.CenterCrop(image_size),
                                            transforms.ToTensor(),
                                            net.ComplexWavelet(num_passes=num_passes),
                                            ])

    dataset = commonDataset(dataroot, data_format, 'labels',
                            transform_trn=transform_trn, transform_val=transform_val,
                            k_fold=k_fold, k=k)
    data_trn = dataset.train_data
    data_val = dataset.validation_data

    assert dataset
    loader_trn = torch.utils.data.DataLoader(data_trn,
                                             batch_size=batch_size,
                                             shuffle=True,
                                             num_workers=int(workers))
    loader_val = torch.utils.data.DataLoader(data_val,
                                             batch_size=val_batch_size,
                                             shuffle=False,
                                             num_workers=int(workers))
    return loader_trn, loader_val, transform_val, dataset.classes


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        error_k = batch_size - correct_k
        res.append(error_k.mul_(100.0 / batch_size))
    return res


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def imagenet_adjust_lr(optimizer, epoch):
    """
    # Sets the learning rate to the initial LR decayed by 10 every 30 epochs
    lr = init_lr * (0.1 ** (epoch // 30))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    """
    if epoch < 30:
        lr = 1e-1
    elif epoch == 30:
        lr = 1e-2
    elif epoch == 60:
        lr = 1e-3
    else:
        return
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def svhn_adjust_lr(optimizer, epoch):
    if epoch < 20:
        lr = 1e-1
    elif epoch == 20:
        lr = 1e-2
    elif epoch == 30:
        lr = 1e-3
    else:
        return
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def cifar_adjust_lr(optimizer, epoch):
    if epoch < 150:
        lr = 1e-1
    elif epoch == 150:
        lr = 1e-2
    elif epoch == 225:
        lr = 1e-3
    elif epoch == 300:
        lr = 1e-4
    else:
        return
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
