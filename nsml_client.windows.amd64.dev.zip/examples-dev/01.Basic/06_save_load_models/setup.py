from distutils.core import setup

setup(
    name='nsml save_load example',
    version='1.1',
    install_requires=[
    ]
)
