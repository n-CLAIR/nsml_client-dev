
## HOW TO RUN AUTOML ON NSML
`nsml automl run` or `nsml automl run -c config.py`


## HOW TO USE CONFIG FILE: (config.py)

Format should be like:
```
    config = {
                'dataset': 'mnist',
                'h_params': {
                    'lr': {'range': [0.001, 0.009], 'distribution': 'uniform', 'type': 'float'},
                    'depth': {'range': [1, 10], 'distribution': 'uniform_int', 'type': 'int'},
                    'size': {'range': [2, 4, 8, 16, 32, 64, 128], 'distribution': 'choice', 'type': 'int'},
                    'activation': {'range': ['relu', 'sigmoid', 'tanh'], 'distribution': 'choice', 'type': 'str'}
                             },

                'population': 2,
                'step': 500,
                'fork': False,
                'order': 'descending',
                'measure': 'test/accuracy',
                'tune': {'pbt': {'exploit': 'truncation', 'explore': 'perturb'}},
                'args': '',
                'entry': 'main.py',
                'maxSessionNumber': 100,
                'automl_gpus': 0
            }

```
1. config must contain dataset,
   other parameters will be default (like in the example above) if not provided.
2. config should be dictionaries.
3. explore functions: perturb, perturb_aggressive, resample, random_explore
4. exploit functions: truncation, avg_compare, last10_compare, binary_tournament
5. you can use custom_explore for explore function, but you should define it in custom_explore.py
   (for more information refer to HOW TO USE CUSTOM EXPLORE)


## HOW TO USE CUSTOM EXPLORE: (custom_explore.py)

1. Function input arguments are current hyperparameters and possible variation.
2. The function must return new hyperparameter values.

Sample example is in custom_explore.py
