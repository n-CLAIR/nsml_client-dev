# -*- coding: utf-8 -*-

from korean_character_parser import decompose_str_as_one_hot
import random
import resource
import csv

if __name__ == '__main__':
    random.seed(1234)
    resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    csv.field_size_limit(500 * 1024 * 1024 * 1000000)

    # Read the data from the top line
    total_lines = []
    column_name_line = []
    with open('raw_data/new_point_after_under30.txt', 'rt', 1024 * 1024 * 2000) as read_csvfile:
        read_line = csv.reader(read_csvfile, delimiter='\t')  # , quotechar='|') # this raise some error
        row = read_line.__next__()
        column_name_line.append([row[3], row[4]])

        for idx, row in enumerate(read_line):
            x = decompose_str_as_one_hot(row[4])
            y = [int(row[3])]
            
            if len(x) <= 0:
                print("Only invalid characters are used.")
                continue

            if len(x) <= 10: # The parsed characters are shorter than 10 length. if you want to use unparsed char, use ' if len(row[4]) <= 4'
                #print(idx, "line skipped - too short comment, score: ", row[3], " comments: ", row[4])
                continue

            #if len(total_lines) >= 1*10000: # stop
                #break

            total_lines.append(y+x)

    # if not shuffle, the dataset is ordered as movie name_code.
    random.shuffle(total_lines)

    print('Total number of instances: ', len(total_lines))

    # split train/test data 
    ratio_of_test = 0.1
    split_point = int( len(total_lines)*(1-ratio_of_test) )

    print('Split index: ', split_point)

    with open('train_movie_review_dataset.csv', 'wt', 1024 * 1024 * 2000) as write_csvfile:
        writer = csv.writer(write_csvfile)
        writer.writerows(column_name_line)
        writer.writerows(total_lines[ : split_point ])
        
    with open('test_movie_review_dataset.csv', 'wt', 1024 * 1024 * 2000) as write_csvfile:
        writer = csv.writer(write_csvfile)
        writer.writerows(column_name_line)
        writer.writerows(total_lines[ split_point : ])

