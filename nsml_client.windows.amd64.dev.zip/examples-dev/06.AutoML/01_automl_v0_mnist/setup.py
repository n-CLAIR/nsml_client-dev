#nsml: nsml/default_ml:latest

from distutils.core import setup
setup(name='hello_automl', version='1.0')
