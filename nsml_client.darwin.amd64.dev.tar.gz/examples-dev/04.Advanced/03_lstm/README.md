# movie review

## Description
LSTM example running on NSML

## How To Run
```bash
# run a session with dataset movie_review and assign entrypoing with lstm.py
$ nsml run -d movie_review -e lstm.py
```
