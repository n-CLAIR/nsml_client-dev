
## HOW TO RUN AUTOML ON NSML
`nsml automl run` or `nsml automl run -c config.yaml`


## HOW TO WRITE CONFIGURATION FILES: (config.yaml)

Let's have a look at how to write a configuration through a concrete example.

```yaml
# config.yaml

backend:
    type: NSMLBackend
    setting:
        dataset: ['automl-mnist']
        entry: train_mnist.py
        cpus: 2
        gpus: 1
        gpu_model: P40
        args: "--batch-size 1024"
tune:
    objective:
        measure: 'test/acc'
        strategy: 'maximize'
    sampler:
        name: RandomSampler
        setting:
    planner:
        name: DefaultPlanner
        setting:
            num_config: 5
# Parameters to tune. Their names should be the exact names that the ArgumentParser takes.
hyperparams:
    lr:
        type: range
        min: 0.001
        max: 0.1
    l2:
        type: log_range
        min: .1e-5
        max: .1e-3
    hidden:
        type: values
        values: [64, 128, 192, 256, 320, 384, 448, 512]
```

Configuration files can be written in either `json` or `yaml` format and have three big parts to them: `backend`, `tune` and `hyperparams`.

### backend

`backend` is where the user specifies which backend he/she wishes to use. Only `NSMLBackend` is supported for the time being. Users can give settings to the backend which is then used to create sessions.

### tune

`tune` determines *how* hyperparameters are tuned and consists of `objective`, `sampler` and `planner`.

1. `objective` specifies *what* to use as the metric (determined by `measure`) and whether to `maximize` or `minimize` (given in `strategy`).
   - **Warning** `measure` should match the name that is shown in the logs output by the backend. For example, in case of `nsml`, if the reporting code looks like `nsml.report(test__acc=...)`, the actual name output by `nsml` would be `'test/acc'`.
2. `sampler` takes in the name of the sampler and its corresponding settings.
3. `planner` takes in the name of the planner and its corresponding settings.

Further details on which samplers / planners are available, please refer to the [documentation](https://pages.oss.navercorp.com/nsml/docs.nsml/_build/html/ko_KR/contents/automl/automl.html).

### hyperparams

In `hyperparams`, the user can set *which* hyperparameters to tune. The names given in this field must be the exact names that the `ArgumentParser` of the entry file recognizes. For example, in the above example configuration (`config.yaml`), `'hidden'` will be passed like this: `python3 run main.py --hidden 512`.

AutoML currently supports (`range`, `log_range` and `values`) as `type`. Of these, `range` and `log_range` must specify `min` and `max`, and for `values`, it should enumerate the possible  `values` as a list.
