import torch 
import torch.nn as nn
import numpy as np
from torch.autograd import Variable


class Generator(nn.Module):
    """Generator. Variational Auto-Encoder."""
    def __init__(self, image_size=64, z_dim=64, conv_dim=64):
        super(Generator, self).__init__()
        
        # Encoder (increasing #filter linearly)
        layers = []
        layers.append(nn.Conv2d(3, conv_dim, kernel_size=3, padding=1))
        layers.append(nn.BatchNorm2d(conv_dim))
        layers.append(nn.ReLU())
        
        repeat_num = 4
        curr_dim = conv_dim
        for i in range(repeat_num):
            layers.append(nn.Conv2d(curr_dim, conv_dim * (i+2), kernel_size=4, stride=2, padding=1))
            layers.append(nn.BatchNorm2d(conv_dim * (i+2)))
            layers.append(nn.ReLU())
            curr_dim = conv_dim * (i+2)
        
        k_size = int(image_size / 16)
        layers.append(nn.Conv2d(curr_dim, z_dim*2, kernel_size=k_size))
        self.encoder = nn.Sequential(*layers)
        
        # Decoder (320 - 256 - 192 - 128 - 64)
        layers = []
        layers.append(nn.ConvTranspose2d(z_dim, curr_dim, kernel_size=k_size))
        layers.append(nn.BatchNorm2d(curr_dim))
        layers.append(nn.ReLU())
        
        repeat_num = 4
        for i in reversed(range(repeat_num)):
            layers.append(nn.ConvTranspose2d(curr_dim , conv_dim * (i+1), kernel_size=4, stride=2, padding=1))
            layers.append(nn.BatchNorm2d(conv_dim * (i+1)))
            layers.append(nn.ReLU())
            curr_dim = conv_dim * (i+1)
        
        layers.append(nn.Conv2d(curr_dim, 3, kernel_size=3, padding=1))
        self.decoder = nn.Sequential(*layers)
    
    def reparameterize(self, mu, log_var):
        eps = torch.randn(mu.size(0), mu.size(1), 1, 1)
        if torch.cuda.is_available:
            eps = eps.cuda()
        z = mu + Variable(eps) * torch.exp(log_var/2)    # 2 for convert var to std
        return z
        
    def forward(self, x):
        h = self.encoder(x)                             # (?, z_dim*2, 1, 1)
        mu, log_var = torch.chunk(h, chunks=2, dim=1)
        z = self.reparameterize(mu, log_var)
        return self.decoder(z), mu, log_var              
    
    def decode(self, z):
        z = z.view(z.size(0), z.size(1), 1, 1)
        return self.decoder(z)
    

class Discriminator(nn.Module):
    """Discriminator."""
    def __init__(self, image_size=64, conv_dim=64):
        super(Discriminator, self).__init__()
        layers = []
        layers.append(nn.Conv2d(3, conv_dim, kernel_size=4, stride=2, padding=1))
        layers.append(nn.LeakyReLU(0.2))
        
        repeat_num = int(np.log2(image_size)) - 3
        curr_dim = conv_dim
        for i in range(repeat_num):
            layers.append(nn.Conv2d(curr_dim, conv_dim * (i+2), kernel_size=4, stride=2, padding=1))
            layers.append(nn.BatchNorm2d(conv_dim * (i+2)))
            layers.append(nn.LeakyReLU(0.2))
            curr_dim = conv_dim * (i+2)
        
        layers.append(nn.Conv2d(curr_dim, 1, kernel_size=4))
        self.main = nn.Sequential(*layers)
        
    def forward(self, x):
        return self.main(x)