# visdom

## Description

Example to see how visdom works in NSML with dummy data

## How To Run

```bash
# run a session with no dataset 
$ nsml run
# session name will be displayed

# Launch plot servers 
$ nsml plot SESSION_NAME

# Open your favorite browser 
# http://[IP prompted on console]:8097

```

Tensorboard will not work on this example
