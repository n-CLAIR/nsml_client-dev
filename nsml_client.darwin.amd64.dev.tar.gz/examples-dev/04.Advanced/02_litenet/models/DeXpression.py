import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True


class SELU(nn.Module):
    def __init__(self):
        super(SELU, self).__init__()
        self.alpha = 1.6732632423543772848170429916717
        self.scale = 1.0507009873554804934193349852946

    def forward(self, x):
        return self.scale * F.relu(x) + self.scale * self.alpha * (F.elu(-1 * F.relu(-1 * x)))


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3),
            SELU(),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.BatchNorm2d(64)
        )

        self.feat_conv_1 = self.feat_conv(64)
        self.feat_pool_1 = self.feat_pool(64)

        self.feat_conv_2 = self.feat_conv(272)
        self.feat_pool_2 = self.feat_pool(272)

        self.fc = nn.Linear(272 * 15 * 15, 7)

    @staticmethod
    def feat_conv(input):
        conv_block = nn.Sequential(
            nn.Conv2d(input, 96, kernel_size=1),
            SELU(),
            nn.Conv2d(96, 208, kernel_size=3, padding=1),
            SELU()
        )
        return conv_block

    @staticmethod
    def feat_pool(input):
        pool_block = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
            nn.Conv2d(input, 64, kernel_size=1)
        )
        return pool_block

    def forward(self, x):
        features = self.conv(x)

        f1 = self.feat_conv_1(features)
        m1 = self.feat_pool_1(features)

        fx1 = F.max_pool2d(torch.cat([f1, m1], dim=1), kernel_size=3, stride=2)

        f2 = self.feat_conv_2(fx1)
        m2 = self.feat_pool_2(fx1)

        fx2 = F.max_pool2d(torch.cat([f2, m2], dim=1), kernel_size=3, stride=2)
        fx2 = fx2.view(len(fx2), -1)

        return F.log_softmax(self.fc(fx2))
