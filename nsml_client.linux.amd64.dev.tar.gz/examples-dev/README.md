# nsml-examples

1. [Hello nsml](https://oss.navercorp.com/nsml/nsml-examples/tree/master/01.Basic/01_hello_nsml)

2. Cnn models of NSML [Pytorch](https://oss.navercorp.com/nsml/nsml-examples/tree/master/01.Basic/02_mnist_pytorch), [Keras](https://oss.navercorp.com/nsml/nsml-examples/tree/master/01.Basic/03_mnist_keras), [Tensorflow](https://oss.navercorp.com/nsml/nsml-examples/tree/master/01.Basic/04_mnist_tensorflow)

3. Preprocessing with NFS system [preprocess](https://oss.navercorp.com/nsml/nsml-examples/tree/master/02.Preprocess/01_preprocess)

4. Graph [visdom](https://oss.navercorp.com/nsml/nsml-examples/tree/master/03.Graph/01_visdom)

5. Advanced Models [VaeGan](https://oss.navercorp.com/nsml/nsml-examples/tree/master/04.Advanced/01_vae_gan), [LiteNet](https://oss.navercorp.com/nsml/nsml-examples/tree/master/04.Advanced/02_litenet), [Lstm](https://oss.navercorp.com/nsml/nsml-examples/tree/master/04.Advanced/03_lstm), [LadderNetwork](https://oss.navercorp.com/nsml/nsml-examples/tree/master/04.Advanced/04_ladder_networks)

6. Distributed training [Distributed_mnist](https://oss.navercorp.com/nsml/nsml-examples/tree/master/05.Distributed/01_distributed_mnist), [Distributed_cifar100](https://oss.navercorp.com/nsml/nsml-examples/tree/master/05.Distributed/02_distributed_cifar100), [Imagenet_resnet](https://oss.navercorp.com/nsml/nsml-examples/tree/master/05.Distributed/03_imagenet_resnet)
