# preprocess

## Description

Example write and read file in NFS system

## How To Run

```bash
# run a session
$ nsml run -d tt-test --nfs-output
```
