# hello_nsml

## Description

Dummy example to test nsml command with multi dataset

If multiple datasets are specified, the dataset is converted to a `list`.

## How To Run
```bash
# run a session with dataset name hello_nsml
$ nsml run -d hello_nsml -d mnist
# session name will be displayed
Session KRXXXXX/hello_nsml/X started.

# you can view the outputs of the script using the logs command
$ nsml logs KRXXXXX/hello_nsml/X
```