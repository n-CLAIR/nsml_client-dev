# Multi-node training 
데이터 병렬화 학습 예제 코드입니다. 명령어 실행 코드는 각 예제에서 확인해주세요.

## How
1. 서버간 통신을 위한 초기화 준비
```python
torch.distributed.init_process_group(backend=“nccl”, init_method=“tcp://10.1.1.20:23456”, world_size=4, rank=0)
```
2. 데이터셋 분할을 위한 초기화 준비
```python
train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset)
```
3. 멀티 프로세싱으로 작업 실행
```python
import torch.multiprocessing as mp
mp.spawn(main, (args, ), nprocs=int(GPU_NUM), join=True)
```

## Note
- 멀티노드 학습을 위해 `nsml run`에 인자를 넘겨주세요.
  - use `--num-nodes`(`-n`) option
  - without specifying the number of GPU, one GPU will be allocated per Node
  - use `--gpus` (`-g`) option to specify the number of GPU per Node
- 환경변수 부여는 python 코드에서 주입해 주세요.
```python
import os
os.environ["NCCL_DEBUG"]="info"
```
- 세션 실행 후, 해당 세션으로 쉘 커맨드를 날릴 떄는 `nsml sh`를 이용하면 됩니다.
```
nsml sh KR99999/imagenet2012_nfs/2 "nvidia-smi"
```
- nsml run 실행 시, 다양한 옵션으로 돌리려는 세션의 리소스를 설정할 수 있습니다. 자세한 내용은 --help 및 도큐먼트를 참조해주세요.
```
nsml run --gpu-driver-version 410.79 --shm-size 12G --memory 50G -d imagenet2012_nfs -e main.py
// --gpu-driver-version : cuda 버전
// --shm-size : 공유 메모리 크기기
// --memory: 메모리 크
``` 
- 데이터 병렬화와 관련된 torch 패키지들과 호환되는 도커 이미지 버전이 상이할 수 있습니다. requirements.txt 로 실행하고자 하는 이미지 버전이나, 패키지 버전을 명시해주세요.
