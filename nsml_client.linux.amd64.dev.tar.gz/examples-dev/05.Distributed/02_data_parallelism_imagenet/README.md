# imagenet_resnet

## How to Run on nsml

```
$ nsml run -d imagenet2012_nfs -e main.py

# for 2 gpus
$ nsml run -d imagenet2012_nfs -e main.py -a '--batch-size 256' --shm-size 4G -g 2

# for multi-nodes ( 2 GPUs / 2 nodes)
$ nsml run -d imagenet2012_nfs --gpu-driver-version 410.79 -e main.py -a '--batch-size 256' --shm-size 12G -g 2 -n 2

# using local dataset instead of NFS
$ nsml run -d ILSVRC2012_data_only --gpu-driver-version 410.79 -e main.py -a '--batch-size 256' --shm-size 12G -g 2 -n 2
```

## Reference
- https://github.com/pytorch/examples/tree/master/imagenet