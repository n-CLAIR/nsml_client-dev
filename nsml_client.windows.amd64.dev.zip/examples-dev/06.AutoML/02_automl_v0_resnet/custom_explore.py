import random
import copy


# simple example
def custom_explore(hyperparameters, variations):
    factors = [0.7, 1.3]
    new_hyperparameters = copy.deepcopy(hyperparameters)
    for key, value in variations.items():
        if 'type' in value:
            if value['type'] == 'float' or value['type'] == 'int':
                new_hyperparameters[key] = hyperparameters[key] * random.choice(factors)
            if isinstance(hyperparameters[key], int):
                new_hyperparameters[key] = int(new_hyperparameters[key])
    return new_hyperparameters


'''
Function arguments look like:
        
        hyperparameters = {'lr': 0.02, 'depth': 10, 'momentum': 0.3, 'prob': 0.4, 'sh': 0.7, ......}

        variations = {'lr': {'range': [0.001, 0.2], 'distribution': 'uniform', 'type': 'float'},
                    'depth': {'range': [20, 26, 32, 38, 44, 56, 110, 146, 170], 
                              'distribution': 'choice', 'type': 'int'},
                    'momentum': {'range': [0.1, 0.999], 'distribution': 'uniform', 'type': 'float'},
                    'prob': {'range': [0, 0.7], 'distribution': 'uniform', 'type': 'float'},
                    'sh': {'range': [0.4, 1], 'distribution': 'uniform', 'type': 'float'}
                    }
'''