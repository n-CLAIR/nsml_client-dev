import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True
import torch.nn.parallel
import math


class SpatiallySeparable(nn.Module):
  def __init__(self, inp, oup, stride):
    super(SpatiallySeparable, self).__init__()

    self.SpatiallySeparable = nn.Sequential(
      nn.Conv2d(inp, inp, (3, 1), (stride, 1), (1, 0), groups=inp, bias=False),
      nn.BatchNorm2d(inp),

      nn.Conv2d(inp, oup, (1, 3), (1, stride), (0, 1), groups=inp, bias=False),
    )

  def forward(self, x):
    return self.SpatiallySeparable(x)


class BottleneckBlock(nn.Module):
  def __init__(self, inc, outc, stride):
    super(BottleneckBlock, self).__init__()
    self.stride = stride
    self.inc = inc
    self.outc= outc
    self.stride = stride

    def conv_separable(inp, oup, stride, groups=1):
      return nn.Sequential(
        SpatiallySeparable(inp, inp, stride),
        #nn.Conv2d(inp, inp, 3, stride, 1, groups=inp, bias=False),
        nn.BatchNorm2d(inp),
        #nn.ReLU(inplace=True),

        nn.Conv2d(inp, oup, 1, 1, 0, groups=groups, bias=False),
        nn.BatchNorm2d(oup),
      )

    self.bottleneck = conv_separable(inc, outc, stride)

    self.shortcut = nn.Sequential()
    if stride == 2:
      self.shortcut = nn.Sequential(nn.AvgPool2d(3, stride=2, padding=1))  
    self.relu = nn.ReLU(inplace=True)

  def forward(self, x):
    #import pdb; pdb.set_trace()
    out = self.bottleneck(x)
    res = self.shortcut(x)
    out = torch.cat([out,res], 1) if self.stride == 2 else out+res
    out = self.relu(out)
    return out
  

class Net(nn.Module):
  def __init__(self, in_c=18, base=64, num_classes=1000, layer_config=[1, 5, 1], groups=1, ngpu=1):
    super(Net, self).__init__()
    self.ngpu = ngpu

    conv0 = nn.Conv2d(in_c, base, 1, 1, 0, bias=False)
    bn0= nn.BatchNorm2d(base)
    relu0 = nn.ReLU(inplace=True)
    body = [conv0, bn0, relu0]
    inc = base

    stage = len(layer_config)
    for ind, con in enumerate(layer_config):
      for repeat in range(con):
        body.append(BottleneckBlock(inc, inc, 1))
      if ind < len(layer_config)-1:
        body.append(BottleneckBlock(inc, inc, 2))
        inc *= 2
       
    self.model = nn.Sequential(*body)

    self.output_size = inc
    self.fc = nn.Linear(self.output_size, num_classes)

    for m in self.modules():
      if isinstance(m, nn.Conv2d):
        n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
        m.weight.data.normal_(0, math.sqrt(2. / n))
      elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1)
        m.bias.data.zero_()
      elif isinstance(m, nn.Linear):
        m.bias.data.zero_()


  def forward(self, x):
    if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
      x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
    else: 
      x = self.model(x)
    x = F.avg_pool2d(x, kernel_size=x.size()[2:])
    x = x.view(-1, self.output_size)
    x = self.fc(x)
    return x
