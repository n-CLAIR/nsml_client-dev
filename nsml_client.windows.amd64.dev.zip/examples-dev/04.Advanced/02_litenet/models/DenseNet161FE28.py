import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True

class Net(nn.Module):
  def __init__(self, pretrained=True, ngpu=1):
    super(Net, self).__init__()
    self.ngpu = ngpu
    self.model = models.densenet161(pretrained=pretrained)
    #self.upsample = nn.Upsample(size=(32,32), mode='bilinear')

    model = nn.Sequential()
    module_counter = 0
    for idx in range(7):
      model.add_module('%d' % idx, self.model.features[idx])
      module_counter += 1
    for idx in range(3):
      model.add_module('%d' % (module_counter+idx), self.model.features[7][idx])

    self.model = model

  def forward(self, x):
    if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
      x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
    else: 
      x = self.model(x)
    #x = self.upsample(x)
    return x
